// variable and Aes key declaration
var company="SUDLIFE"
var aih_ENI="A1HS8CUR1TY@9812"
var aih_ENK="A1HS8CUR1TY@9812"
var aih_Enc_Key = CryptoJS.enc.Utf8.parse(aih_ENK);

if(localStorage.getItem('nightMode')) { 
    if (localStorage.getItem('nightMode') === 'on') {
        applyDarkModeChanges();
        document.getElementById("mode_switch").checked = true;
    }
} else {
    // sets local storage for dark mode
    localStorage.setItem('nightMode', 'off');
}

// AesEncrypt function for encrypting the data
AesEncrypt = function (tabNumber) {
    var val = document.getElementById(`plain_text_${tabNumber}`).value;
    var randomNum = "12"
    var result = "";
    if (randomNum != undefined && randomNum != "") {
        aih_Enc_IV = CryptoJS.enc.Utf8.parse((aih_ENI).substring(0, (aih_ENI).length - 2) + randomNum);
        var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(val), aih_Enc_Key,
        {
            keySize: 256 / 8,
            iv: aih_Enc_IV,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        result = encrypted.toString();
    }
    else{
        aih_Enc_IV = CryptoJS.enc.Utf8.parse(aih_ENI);
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(val), aih_Enc_Key,
    {
        keySize: 256 / 8,
        iv: aih_Enc_IV,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    result = encrypted.toString();
    }
    document.getElementById(`cipher_text_${tabNumber}`).value=randomNum+company+"###"+result;
    return result;
};

// AesDecrypt function for decrypting the data in cipher_text
AesDecrypt = function (tabNumber) {
    let jsonObj = {};
    let jsonViewer = new JSONViewer();


    var val = document.getElementById(`cipher_text_${tabNumber}`).value;
    var result = "";
    var decrypted = "";
    if (val.indexOf("###") > 0) {
        var partner_key = val.substring(0, val.indexOf("###"));
        var iv = (aih_ENI).substring(0, (aih_ENI).length - 2) + partner_key.substring(0, 2);
        aih_Enc_IV = CryptoJS.enc.Utf8.parse(iv);
        var content = val.substring(val.indexOf("###") + 3);
        decrypted = CryptoJS.AES.decrypt(content, aih_Enc_Key,
            {
                keySize: 256 / 8,
                iv: aih_Enc_IV,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });
    }
    else {
        aih_Enc_IV = CryptoJS.enc.Utf8.parse(aih_ENI);
        decrypted = CryptoJS.AES.decrypt(val, aih_Enc_Key,
        {
            keySize: 256 / 8,
            iv: aih_Enc_IV,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
    }
    
    result = decrypted.toString(CryptoJS.enc.Utf8);
    var jsonResult= JSON.parse(result);
    if(jsonResult["JSONData"]!=null && jsonResult["JSONData"]!= "" && jsonResult["JSONData"] !=undefined){
        document.getElementById(`json_Result_${tabNumber}`).value=jsonResult["JSONData"];
        $(`#collapse_all_${tabNumber}`).removeClass('hide');
        $(`#expand_all_${tabNumber}`).removeClass('hide');
        showJsonView(tabNumber, jsonResult["JSONData"]);
    }

    document.getElementById(`plain_text_${tabNumber}`).value=result;
    return result;
};

function showJsonView(tabNumber, data, collapseAll) {
    let jsonObj = {};
    let jsonViewer = new JSONViewer();
    $(`#json_${tabNumber}`).text('');
    document.querySelector(`#json_${tabNumber}`).appendChild(jsonViewer.getContainer());
    jsonObj = JSON.parse(data);
    if (collapseAll === 'collapse_to_level_1') { 
        jsonViewer.showJSON(jsonObj, null, 1);
    } else {
        jsonViewer.showJSON(jsonObj);
    }
}

function collapseAllOnClick(tabNumber) {
    let data = document.getElementById(`json_Result_${tabNumber}`).value;
    showJsonView(tabNumber, data, 'collapse_to_level_1')
}

function expandAllOnClick(tabNumber) {
    let data = document.getElementById(`json_Result_${tabNumber}`).value;
    showJsonView(tabNumber, data)
}



function clearAll(tabNumber) {
    document.getElementById(`cipher_text_${tabNumber}`).value = '';
    document.getElementById(`plain_text_${tabNumber}`).value = '';
    document.getElementById(`json_Result_${tabNumber}`).value = '';
    $(`#collapse_all_${tabNumber}`).addClass('hide');
    $(`#expand_all_${tabNumber}`).addClass('hide');
    let json_child_element = $(`#json_${tabNumber}`).children();
    if (json_child_element.length > 0) { 
        textView_tab_onClick(tabNumber);
        json_child_element.remove();
        $(`#json_${tabNumber}`).text('No Data');
    }
}


function onCloseTab(tabNumber) {
    let nextTabs = $(`#item-${tabNumber}`).nextAll().not("#add");
    let nav_item_to_delete = $(`#item-${tabNumber}`);
    let tab_content_to_delete = $(`#tab-${tabNumber}`);
    let prevTab = $(`#item-${tabNumber}`).prev();
    let prevTabContent = $(`#tab-${tabNumber}`).prev();

    // changes the Tab Name for the next tabs if any
    if (nextTabs.length) {
        let count =  parseInt($(".nav-link").filter(".active")[0].innerText.split(' ')[1], 10);
        
        $(`#item-${tabNumber}`).nextAll().not("#add").children().html((i, originalText) => {
            let newTextArray = originalText.trim().split(' ');
            let newHTMLText = originalText.replace(newTextArray[1], count.toString());
            count++;
            return newHTMLText;
        });
    }

    // marks prev tab as active
    prevTab.children().addClass('active');
    prevTabContent.addClass('active show');

    // removes the tab and tab content
    nav_item_to_delete.remove();
    tab_content_to_delete.remove();

    let currentTabLength = $('.nav').children().length;
    currentTabLength === 10 && $("#add").removeClass('disable');
}

function textView_tab_onClick(tabNumber) {
    $(`#text_view_content_${tabNumber}`).removeClass('hide');
    $(`#text_view_content_${tabNumber}`).addClass('show');
    
    $(`#json_view_content_${tabNumber}`).removeClass('show');
    $(`#json_view_content_${tabNumber}`).addClass('hide');

    $(`#json_view_button_${tabNumber}`).removeClass('active');
    $(`#text_view_button_${tabNumber}`).addClass('active');
}

function jsonView_tab_onClick(tabNumber) {
    $(`#text_view_content_${tabNumber}`).removeClass('show');
    $(`#text_view_content_${tabNumber}`).addClass('hide');

    $(`#json_view_content_${tabNumber}`).removeClass('hide');
    $(`#json_view_content_${tabNumber}`).addClass('show');

    $(`#text_view_button_${tabNumber}`).removeClass('active');
    $(`#json_view_button_${tabNumber}`).addClass('active');
}


// copy functionality
function copyToClipBoardFunction(type, tabNumber) {
    let copyTextElement;
    switch (type) {
        case 'encrypt':
            copyTextElement = document.getElementById(`plain_text_${tabNumber}`);
            break;
        case 'decrypt':
            copyTextElement = document.getElementById(`cipher_text_${tabNumber}`);
            break;
        case 'text_view':
            copyTextElement = document.getElementById(`json_Result_${tabNumber}`);
            break;
        default:
            break;
    }
    copyToClipBoard(copyTextElement);
}

function copyToClipBoard(element) {
    var copyText = element;
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
}


function handleDarkMode() {
    let darkMode = localStorage.getItem('nightMode');
    applyDarkModeChanges();
    if (darkMode === 'off') {
        localStorage.setItem('nightMode', 'on');
    }
    if (darkMode === 'on') {
        localStorage.setItem('nightMode', 'off');
    }
};

function applyDarkModeChanges() {
    $('body').toggleClass('bg-dark text-white');
    $('hr').toggleClass('border-color-dark');
    $('.navbar').toggleClass('navbar-light bg-light').toggleClass('navbar-custom-dark text-white');
    $('#Tab_Content').toggleClass('bg-dark text-white');
    $('#add').children().toggleClass('text-white');
    $('.decryption_box').toggleClass('bg-dark text-white');
    $('.encryption_box').toggleClass('bg-dark text-white');
    $('.result_box').toggleClass('bg-dark text-white');
    $('.nav-link').toggleClass('text-white');
    $('.json-view').toggleClass('dark-theme');
    $('.json_view_btn').toggleClass('btn-outline-info').toggleClass('btn-outline-light');
}